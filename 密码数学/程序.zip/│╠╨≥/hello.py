#!/usr/bin/python
# -*- coding: UTF-8 -*-
import math
#求四个奇数点函数
def soved(dmin,dmax):

    if math.ceil(dmin) % 2 == 1:
        if math.ceil(dmin) >= 0:
            d1 = math.ceil(dmin)
            d2 = d1 + 2
        else:
            d1 = math.ceil(dmin)
            d2 = d1 - 2

    else:
        if math.ceil(dmin) >= 0:
            d1 = math.ceil(dmin) - 1
            d2 = d1 + 2
        else:
            d1 = math.ceil(dmin) - 1
            d2 = d1 + 2

    if math.ceil(dmax)% 2== 1:
        if math.ceil(dmax) >= 0:
            d3 = math.ceil(dmax)
            d4 = d3 + 2
        else:
            d3 = math.ceil(dmax)
            d4 = d3 - 2

    else:
        if math.ceil(dmax) >= 0:
            d3 = math.ceil(dmax) - 1
            d4 = d3 + 2
        else:
            d3 = math.ceil(dmax) - 1
            d4 = d3 + 2

    return [d1, d2, d3, d4]

with open('sequence.txt', 'r') as f:
    data = f.readline()
    A= list(map(int, data))
#找到第一个非0位
k=0
if k<len(A) and A[k]==0:
    k=k+1
    f=[2,0]
    g=[0,1]
#定义初值
alfa =A[k] * (2**(k))
f=[0,2]
g=[2**(k),1]
#开始循环
kk=k+1
while kk<len(A):
    ak = A[kk]
    alfa = alfa + (ak*2**(kk))
    if (alfa*g[1]-g[0])%(2**(kk+1)) == 0:
        print ("正在执行第一个If！")
        f=[2 * f[0], 2 * f[1]]
    elif max(abs(g[0]),abs(g[1])) < max(abs(f[0]),abs(f[1])):
        print ("正在执行第二个If！")
        dmin = (f[1] - f[0]) / (g[0] - g[1])
        dmax = -(f[0] + f[1]) / (g[0] + g[1])
        D = soved(dmin, dmax)
        d = {D[0]: max(abs(f[0] + D[0] * g[0]), abs(f[1] + D[0] * g[1])),
             D[1]: max(abs(f[0] + D[1] * g[0]), abs(f[1] + D[1] * g[1])),
             D[2]: max(abs(f[0] + D[2] * g[0]), abs(f[1] + D[2] * g[1])),
             D[3]: max(abs(f[0] + D[3] * g[0]), abs(f[1] + D[3] * g[1]))}
        mifdg=min(d, key=d.get)
        g1=g
        g=[f[0]+mifdg * g1[0],f[1]+mifdg * g1[1]]
        f=[2 * g1[0],2 * g1[1]]
    else:
        print ("正在执行第三个If！")
        dmin = (g[1] - g[0]) / (f[0] - f[1])
        dmax = -(g[0] + g[1]) / (f[0] + f[1])
        D = soved(dmin, dmax)
        d = {D[0]: max(abs(g[0] + D[0] * f[0]), abs(g[1] + D[0] * f[1])),
             D[1]: max(abs(g[0] + D[1] * f[0]), abs(g[1] + D[1] * f[1])),
             D[2]: max(abs(g[0] + D[2] * f[0]), abs(g[1] + D[2] * f[1])),
             D[3]: max(abs(g[0] + D[3] * f[0]), abs(g[1] + D[3] * f[1]))}
        migdf= min(d, key=d.get)
        g = [g[0] +migdf * f[0], g[1] +migdf * f[1]]
        f = [2 * f[0], 2 * f[1]]
    kk=kk+1
    p=g[0]
    q=g[1]
    An=p/q
    fai=max(abs(p),abs(q))
    # 输出结果（保证q为正奇数）
    if (g[1]<0):
        lastg=[-g[0],-g[1]]
        print("第", kk, "组g值是: ", lastg)
    else:
        print("第", kk, "组g值是: ", g)
    print("第", kk, "组f值是: ", f)
    print("有理序列表示是：", An)
    print("φ值是：", fai)
    #执行验证程序
    print ("正在执行验证程序！")
    if (g[1]*alfa%2**kk)==(g[0]%2**kk):
        print ("结果正确！")
    else:
        print("第", kk, "组结果不正确！: ",g)